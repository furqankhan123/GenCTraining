package com.example.petclinic.business;

import com.example.petclinic.model.Owner;
import com.example.petclinic.service.OwnerService;
import com.example.petclinic.service.PetService;
import org.springframework.stereotype.Component;

@Component
public class PetClinicBusinessWorkFlow {

    OwnerService ownerService;
    PetService petService;

    public PetClinicBusinessWorkFlow(OwnerService ownerService, PetService petService) {
        this.ownerService = ownerService;
        this.petService = petService;
    }

    public void runBusiness() {
        String address = "742 Evergreen Terrace";
        String city = "Springfield";
        String phoneNumber = "9395550113";

        Owner owner1 = Owner.builder().withName("Homer Simpson").withAddress(address).withCity(city).withPhoneNumber(phoneNumber).build();
        Owner owner2 = Owner.builder().withName("Marge Simpson").withAddress(address).withCity(city).withPhoneNumber(phoneNumber).build();
        Owner owner3 = Owner.builder().withName("Bart Simpson").withAddress(address).withCity(city).withPhoneNumber(phoneNumber).build();
        Owner owner4 = Owner.builder().withName("Lisa Simpson").withAddress(address).withCity(city).withPhoneNumber(phoneNumber).build();

        // Add Owners
        ownerService.saveOwner(owner1);
        ownerService.saveOwner(owner2);
        ownerService.saveOwner(owner3);
        ownerService.saveOwner(owner4);

        // Get All Owners
        ownerService.getAllOwners();
    }
}
