package com.example.petclinic.service;


import com.example.petclinic.GetAllOwner;
import com.example.petclinic.PetClinicClient;
import com.example.petclinic.model.Owner;
import com.sun.deploy.jcp.CertificatesCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

public class OwnerService {
    private static final Logger log = LoggerFactory.getLogger(OwnerService.class);

    RestTemplate restTemplate;

    public OwnerService(RestTemplate restTemplate){
        this.restTemplate = restTemplate;
    }

    public Owner saveOwner(Owner owner){
        URI uri = URI.create("http://localhost:9090/owner/addOwner");

        Owner response = restTemplate.postForObject(uri, owner, Owner.class);
        log.info(response.toString());
        return response;
    }

}
